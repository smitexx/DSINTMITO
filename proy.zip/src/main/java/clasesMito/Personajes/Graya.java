package clasesMito.Personajes;

import java.util.List;

import clasesMito.Objeto;
import clasesMito.Personaje;

public class Graya extends Inmortal {

	public Graya(Personaje hijoDe, List<Objeto> inventario, String nombre, List<Personaje> padreDe) {
		super(hijoDe, inventario, nombre, padreDe);
		// TODO Auto-generated constructor stub
	}

}
