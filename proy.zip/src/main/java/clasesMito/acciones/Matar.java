package clasesMito.acciones;

import clasesMito.Accion;
import clasesMito.Personaje;

public class Matar extends Accion {

	public Matar(Personaje sujeto, Personaje afectadoP) {
		super(sujeto, afectadoP);
		// TODO Auto-generated constructor stub
	}

}
