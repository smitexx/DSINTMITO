package clasesMito.acciones;

import clasesMito.Accion;
import clasesMito.Personaje;

public class Liberar extends Accion {

	public Liberar(Personaje sujeto, Personaje afectadoP) {
		super(sujeto, afectadoP);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Liberar [" + getSujeto() + "," + getAfectadoP() + "]";
	}
	
}
