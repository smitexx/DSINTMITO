package clasesMito.acciones;

import clasesMito.Accion;
import clasesMito.Personaje;

public class Apresar extends Accion {

	public Apresar(Personaje sujeto, Personaje afectadoP) {
		super(sujeto, afectadoP);
	}
	
}
