package clasesMito.acciones;

import clasesMito.Accion;
import clasesMito.Objeto;
import clasesMito.Personaje;

public class Obtener extends Accion {

	public Obtener(Personaje sujeto, Objeto afectadoC) {
		super(sujeto, afectadoC);
		// TODO Auto-generated constructor stub
	}

}
