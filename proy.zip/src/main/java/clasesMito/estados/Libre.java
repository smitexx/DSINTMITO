package clasesMito.estados;

import clasesMito.Estado;
import clasesMito.Personaje;

public class Libre extends Estado {

	public Libre(Personaje sujeto) {
		super(sujeto);
	}
	
}
