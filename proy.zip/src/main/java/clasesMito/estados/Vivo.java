package clasesMito.estados;

import clasesMito.Estado;
import clasesMito.Personaje;

public class Vivo extends Estado {

	public Vivo(Personaje sujeto) {
		super(sujeto);
		// TODO Auto-generated constructor stub
	}

}
