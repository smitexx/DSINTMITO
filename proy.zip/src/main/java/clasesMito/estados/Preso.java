package clasesMito.estados;

import clasesMito.Estado;
import clasesMito.Personaje;

public class Preso extends Estado{

	public Preso(Personaje sujeto) {
		super(sujeto);
		// TODO Auto-generated constructor stub
	}

}
