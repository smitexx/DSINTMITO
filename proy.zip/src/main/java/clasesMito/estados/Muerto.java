package clasesMito.estados;

import clasesMito.Estado;
import clasesMito.Personaje;

public class Muerto extends Estado {

	public Muerto(Personaje sujeto) {
		super(sujeto);
	}

}
